#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define INF INT_MAX

typedef struct Edge
{
    int s;
    int d;
    int w;
} edge;

typedef struct Graph
{
    int v;
    int e;
    edge *einfo;
} graph;

typedef struct Node
{
    struct Node *next;
    int v;
} node;

node *node_init(int v)
{
    node *new = (node *)malloc(sizeof(node));
    new->v = v;
    new->next = NULL;
    return new;
}

graph *init(int v, int e)
{
    graph *g = (graph *)malloc(sizeof(g));
    g->v = v;
    g->e = e;
    g->einfo = (edge *)malloc(e * sizeof(edge));
    return g;
}

void track(int p[], int s, int d)
{
    if (s == d)
    {
        printf("%d ", s + 1);
        return;
    }
    track(p, s, p[d]);
    printf("%d ", d + 1);
}

void print(int dist[], int path[], int s, int v)
{
    for (int i = 0; i < v; i++)
    {
        if (i != s)
        {
            printf("%d %d length: ", s + 1, i + 1);
            if (dist[i] == INF)
                printf("inf path: none\n");
            else
            {
                printf("%d path: ", dist[i]);
                track(path, s, i);
                printf("\n");
            }
        }
    }
}

int bf(graph *g, int s)
{
    int v = g->v;
    int e = g->e;
    int dist[2000];
    int p[v];

    for (int i = 0; i < v; i++)
    {
        dist[i] = INF;
        p[i] = -1;
    }

    dist[s] = 0;
    for (int i = 1; i <= v - 1; i++)
    {
        for (int j = 0; j < e; j++)
        {
            int u = g->einfo[j].s;
            int v = g->einfo[j].d;
            int w = g->einfo[j].w;
            if (dist[u] != INF && dist[u] + w < dist[v])
            {
                dist[v] = dist[u] + w;
                p[v] = u;
            }
        }
    }

    for (int i = 0; i < e; i++)
    {
        int start = g->einfo[i].s;
        int end = g->einfo[i].d;
        int w = g->einfo[i].w;
        if (dist[start] != INF && dist[start] + w < dist[end])
        {
            printf("Error: negative-cost cycle found\n");
            return 0;
        }
    }
    print(dist, p, s, v);
    return 1;
}

int main(int argc, char *argv[])
{
    char cmd[1024];
    int v, e;
    int n;
    int flag;

    if (fgets(cmd, sizeof(cmd), stdin) != NULL)
    {
        n = sscanf(cmd, "%d %d", &v, &e);

        if (n != 2)
        {
            printf("Error: Expected two numbers in the first line.\n");
            return 0;
        }
    }
    graph *g = init(v, e);
    for (int i = 0; i < e; i++)
    {
        if (fgets(cmd, sizeof(cmd), stdin) != NULL)
        {
            int s, d, w;
            n = sscanf(cmd, "%d %d %d", &s, &d, &w);
            if (n != 3)
            {
                printf("Error: Expected three numbers in line %d .\n", i + 2);
                return 0;
            }
            if (s < 1 || s > v || d < 1 || d > v)
            {
                printf("vertex out of bound\n");
                return 0;
            }
            g->einfo[i].s = s - 1;
            g->einfo[i].d = d - 1;
            g->einfo[i].w = w;
        }
    }

    if (argc == 1)
    {
        for (int i = 0; i < v; i++)
        {
            flag = bf(g, i);
            if (flag == 0)
                break;
        }
    }
    else if (argc == 2)
    {
        int start = atoi(argv[1]);
        if (start < 1 || start > v)
        {
            printf("invalid start vertex\n");
            return 0;
        }
        flag = bf(g, start - 1);
    }

    free(g->einfo);
    free(g);

    return 0;
}