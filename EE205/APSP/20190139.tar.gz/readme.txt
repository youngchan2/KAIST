1.
[Bellman-Ford]
먼저 그래프의 정보를 저장할 graph 타입과 directed edge 정보를 저장할 edge 타입을 structure로 정의했다.
각 structure를 초기화할 init 함수를 만들었고 fgets와 sscanf를 통해 입력 형식에서 문제가 생길 경우 에러 메세지를 출력하였다.
출력 형식의 문제에는 입력의 첫 줄의 숫자가 두개가 아닌 경우, 그 다음 줄의 숫자가 세개가 아닌 경우, vertex의 범위를 벗어난 경우 총 세가지이다.

이후 command에 숫자가 입력하면 시작점을 정해준 것이기 때문에 Bellman-Ford 알고리즘을 해당 숫자로만 진행하도록 조건문을 나눠주었다.
숫자가 주어지지 않는 경우 전체 vertex에 대해 모든 path를 나타내야하므로 반복문을 통해 모든 vertex에 대해 Bellman-Ford 알고리즘을 적용시켰다.

Bellman-Ford알고리즘은 시작점의 거리를 0으로 두고 나머지 점들을 inf로 초기 설정한다. 그 이후에 이동 가능한 vertex를 찾으며 거리를 update한다.
경로 또한 출력해야하므로 거리를 update하는 과정에서 경로를 저장할 array도 같이 update 해준다.
거리를 update하는 경우는 기존에 가지고 있던 거리와 다른 점을 지나서 온 경우와 비교했을 때 후자가 더 작은 경우 update한다.
이 때 경로 또한 지나서 온점을 저장해둔다. 이를 총 v-1번 반복한다.
negative cycle를 찾기 위해 한번더 거리 비교를 해서 update가 되면 negative cycle이 존재하는 것이므로 에러 메세지를 출력한다.
update 되지 않았으면 저장했던 경로를 추적해서 경로를 출력하면 된다.

[Floyd-Warshall]
전체적인 형태는 Bellman-Ford와 동일하다.
차이점은 알고리즘 구현 방식에서 Floyd-Warshall은 처음부터 전체 vertex에 대해 최단경로를 찾는 것이다. adjacent matrix를 사용한다.
또한 1번 vertex를 지나쳐 가는 경우에 대해 update, 2번 vertex를 지나쳐 가는 경우에 대해 update 등등 지나치는 점을 기준으로 update한다.
negative cycle를 찾는 방법은 위의 반복을 한번더 진행해 adjacent matrix의 대각성분이 update되는 경우 negative cycle이 존재하는 것이다.
error가 생기는 경우 또한 Bellman-Ford와 동일하다.

2.
Bellman-Ford 알고리즘에서 time complexity는 vertex 하나당 O(ve)이다. APSP로 볼 경우 전체 vertex 개수 v개에 대해서 반복해야하므로 O(v^2e)가 된다.
Floyd-Warshall 알고리즘에서 time complexity는 O(v^3)이다. 
일반적으로 큰 graph인 경우에 edge수가 vetex 수에 비해 훨씬 많으므로 APSP를 구현하는 경우에는 Floyd-Warshall 알고리즘이  Bellman-Ford 알고리즘에 비해 빠르다.

input_2.txt 그래프를 사용해서 시간을 직접 측정해본 결과
Floyd-Warshall은 10.7초가 나왔고 Bellman-Ford는 vertex 한개에 대해서 3.4초가 걸렸다. input_2의 vertext개수는 1000개 이므로 전체에 대해선 대략 3400초가 걸릴 것이다.