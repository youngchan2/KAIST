#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define INF INT_MAX

typedef struct Graph
{
    int v;
    int e;
    int **adj;
} graph;

typedef struct Node
{
    struct Node *next;
    int v;
} node;

node *node_init(int v)
{
    node *new = (node *)malloc(sizeof(node));
    new->v = v;
    new->next = NULL;
    return new;
}

graph *init(int v, int e)
{
    graph *g = (graph *)malloc(sizeof(graph));
    g->v = v;
    g->e = e;
    g->adj = (int **)malloc(v * sizeof(int *));
    for (int i = 0; i < v; i++)
    {
        g->adj[i] = (int *)malloc(v * sizeof(int));
        for (int j = 0; j < v; j++)
        {
            if (i == j)
            {
                g->adj[i][j] = 0;
            }
            else
            {
                g->adj[i][j] = INF;
            }
        }
    }
    return g;
}

void freepath(node *path)
{
    while (path != NULL)
    {
        node *tmp = path;
        path = path->next;
        free(tmp);
    }
}

void freegraph(graph *g)
{
    for (int i = 0; i < g->v; i++)
        free(g->adj[i]);
    free(g->adj);
    free(g);
}

void track(int p[], int d, int s)
{
    node *path = node_init(d);
    int current = d;
    while (p[current] != s)
    {
        node *new = node_init(p[current]);
        new->next = path;
        path = new;
        current = p[current];
    }
    node *source = node_init(s);
    source->next = path;
    path = source;

    while (path != NULL)
    {
        printf("%d ", path->v + 1);
        path = path->next;
    }
    freepath(path);
}

void print(graph *g, int path[][g->v])
{
    int v = g->v;
    for (int i = 0; i < v; i++)
    {
        for (int j = 0; j < v; j++)
        {
            if (i != j)
            {
                printf("%d %d length: ", i + 1, j + 1);
                if (g->adj[i][j] == INF)
                {
                    printf("inf path: none\n");
                }
                else
                {
                    printf("%d path: ", g->adj[i][j]);
                    track(path[i], j, i);
                    printf("\n");
                }
            }
        }
    }
}

void fw(graph *g)
{
    int v = g->v;
    int p[v][v];

    for (int i = 0; i < v; i++)
    {
        for (int j = 0; j < v; j++)
        {
            if (i != j && g->adj[i][j] != INF)
                p[i][j] = i;
            else
                p[i][j] = -1;
        }
    }

    for (int k = 0; k < v; k++)
    {
        for (int i = 0; i < v; i++)
        {
            for (int j = 0; j < v; j++)
            {
                if (g->adj[i][k] != INF && g->adj[k][j] != INF && g->adj[i][k] + g->adj[k][j] < g->adj[i][j])
                {
                    g->adj[i][j] = g->adj[i][k] + g->adj[k][j];
                    p[i][j] = p[k][j];
                }
            }
        }
    }

    for (int i = 0; i < v; i++)
    {
        if (g->adj[i][i] < 0)
        {
            printf("Error: negative-cost cycle found\n");
            return;
        }
    }

    print(g, p);
}

int main()
{
    char cmd[1024];
    int v, e;
    int n = 0;
    if (fgets(cmd, sizeof(cmd), stdin) != NULL)
    {
        n = sscanf(cmd, "%d %d", &v, &e);
        if (n != 2)
        {
            printf("Error: Expected two numbers in the first line.\n");
            return 0;
        }
    }

    graph *g = init(v, e);

    for (int i = 0; i < e; i++)
    {
        if (fgets(cmd, sizeof(cmd), stdin) != NULL)
        {
            int s, d, w;
            n = sscanf(cmd, "%d %d %d", &s, &d, &w);
            if (n != 3)
            {
                printf("Error: Expected three numbers in line %d .\n", i + 2);
                return 0;
            }
            if (s < 1 || s > v || d < 1 || d > v)
            {
                printf("vertex out of bound\n");
                return 0;
            }
            g->adj[s - 1][d - 1] = w;
        }
    }

    fw(g);
    freegraph(g);

    return 0;
}